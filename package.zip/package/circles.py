def circlearea(r):
	area=3.14*r*r
	print("\n\tArea of a circle = ",round(area,2))
def circleperi(r):
	peri=2*3.14*r
	print("\n\tPerimeter of a circle = ",round(peri,2))
