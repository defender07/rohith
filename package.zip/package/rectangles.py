def rectarea(l,b):
	print("\n\tArea of a rectangle = ",l*b)
def rectperi(l,b):
	print("\n\tPerimeter of a rectangle = ",2*(l+b))
	
