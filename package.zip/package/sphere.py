def spherearea(r):
	area=2*3.14*r*r
	print("\n\tArea of sphere : ",round(area,2))
def sphereperi(r):
	peri=4*3.14*r*r
	print("\n\tPerimeter of sphere : ",round(peri,2))
	
