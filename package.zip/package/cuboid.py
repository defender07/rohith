def cuboidarea(l,b,h):
	area=2*((l*b)+(l*h)+(b*h))
	print("\n\tArea of cuboid : ",round(area,2))
def cuboidperi(l,b,h):
	peri=4*(l+b+h)
	print("\n\tPerimeter of cuboid : ",round(peri,2))
	
